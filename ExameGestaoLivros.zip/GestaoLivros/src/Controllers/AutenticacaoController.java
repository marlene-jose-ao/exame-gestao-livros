
package Controllers;

import Dao.GeneralDAO;
import ViewsUI.LoginView;
import ViewsUI.SignUpView;


public class AutenticacaoController {
    public GeneralDAO context;
    
    public AutenticacaoController(GeneralDAO _context) {
        context = _context;
    }
    
    public void LoginAction(){
        new LoginView(context).setVisible(true);
    }
    
    public void SignUpAction(){
        new SignUpView(context).setVisible(true);
    }
}
