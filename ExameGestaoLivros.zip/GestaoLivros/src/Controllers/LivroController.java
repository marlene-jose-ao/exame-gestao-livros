
package Controllers;

import Dao.GeneralDAO;
import Dao.LivroDAO;
import ViewsUI.LivroView;

public class LivroController {
    public GeneralDAO context;
    public AutenticacaoController loginAuth = new AutenticacaoController(context);
    private final LivroDAO livroDAO = new LivroDAO();

    public LivroController(GeneralDAO _context) {
        context = _context;
    }

    public void IndexAction() {
        if (context.isAuthenticated())
            new LivroView(context).setVisible(true);
        else
            loginAuth.LoginAction();
    }
    
    public void exportarTarefasParaPDF(String filePath) {
        livroDAO.exportarLivrosParaPDF(filePath);
    }

}
