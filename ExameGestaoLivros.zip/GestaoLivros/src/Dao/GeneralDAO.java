package Dao;

import Controllers.AutenticacaoController;
import Controllers.LivroController;
import Dtos.LivroDTO;
import Models.Livro;
import Models.Usuario;
import java.awt.Toolkit;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;
import javax.swing.JOptionPane;

public class GeneralDAO {
    private final LivroDAO livroDAO = new LivroDAO();
    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private ArrayList<Usuario> usuarios = new ArrayList<>();
    private ArrayList<Livro> livros = new ArrayList<>();
    private final LivroController livroController = new LivroController(this);
    private final AutenticacaoController loginController = new AutenticacaoController(this);

    public Usuario usuarioLogado;

    Integer tarefaId = 1;

    /* ===================== Gestão de Tarefas ====================== */
    public void CriarTarefa(LivroDTO livro) {
        try {
            Livro novoLivro = new Livro();

            novoLivro.setId(tarefaId);
            novoLivro.setTitle(livro.getTitle());
            novoLivro.setDescription(livro.getDescription());
            novoLivro.setAuthor(livro.getAuthor());

            if (isAuthenticated()) {
                novoLivro.setCreatedBy(usuarioLogado);
                novoLivro.setUpdatedBy(usuarioLogado);
            }

            novoLivro.setCreatedAt(LocalDate.now());
            novoLivro.setUpdatedAt(LocalDate.now());

            livroDAO.adicionarLivro(novoLivro);
            Notificar("Criação de Livro", "livro criado com sucesso", JOptionPane.INFORMATION_MESSAGE);
            tarefaId++;
        } catch (Exception e) {
            Notificar("Erro ao criar Livro", e.getMessage(), JOptionPane.ERROR_MESSAGE);
        }
    }

    public ArrayList<Livro> PegarLivros() {
        livros = (ArrayList<Livro>) livroDAO.listarlivros();
        return livros;
    }

    public ArrayList<Livro> PegarLivrosPorFiltros(String Titulo) {
        var encontrados = new ArrayList<Livro>();

        PegarLivros().forEach((t) -> {
            if (t.getTitle().toLowerCase().contains(Titulo.toLowerCase())) {
                encontrados.add(t);
            }
        });

        return encontrados;
    }

    public Livro PegarLivroPorId(Integer id) {

        try {
            Livro encontrado = null;

            for (Livro livro : PegarLivros()) {
                if (Objects.equals(livro.getId(), id)) {
                    encontrado = livro;
                }
            }
            if (encontrado != null) {
                return encontrado;
            } else {
                Notificar("Buscar Livro",
                        "Livro não encontrado!!!",
                        JOptionPane.WARNING_MESSAGE);
            }

        } catch (Exception ex) {
            Notificar("Erro ao Buscar Livro",
                    ex.getMessage(),
                    JOptionPane.ERROR_MESSAGE);
        }

        return null;
    }

    public void ExcluirLivro(Integer id) {
        try {
            Livro encontrado = PegarLivroPorId(id);

            if (encontrado != null) {
                livroDAO.excluirLivro(encontrado.getId());
                Notificar("Exclusão de Livro", "livro removido com sucesso", JOptionPane.INFORMATION_MESSAGE);
            } else {
                Notificar("Buscar Livro",
                        "Livro não encontrado!!!",
                        JOptionPane.WARNING_MESSAGE);
            }

        } catch (Exception ex) {
            Notificar("Erro ao Buscar Livro",
                    ex.getMessage(),
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    public void EditarLivro(Livro livro) {
        try {
            Livro encontrado = PegarLivroPorId(livro.getId());
            Integer posicao = PegarLivros().indexOf(encontrado);
            if (encontrado != null) {

                if (isAuthenticated()) {
                    livro.setUpdatedBy(usuarioLogado);
                }

                livro.setUpdatedAt(LocalDate.now());

                livroDAO.editarLivro(livro);

                Notificar("Edição de Livro", "Livro atualizado com sucesso", JOptionPane.INFORMATION_MESSAGE);
            } else {
                Notificar("Buscar Livro",
                        "Livro não encontrado!!!",
                        JOptionPane.WARNING_MESSAGE);
            }

        } catch (Exception ex) {
            Notificar("Erro ao atualizar livro",
                    ex.getMessage(),
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    public void ExportToPdf(){
        String filePath = "livros_"+new Date().getTime()+ ".pdf";
        livroController.exportarTarefasParaPDF(filePath);
                JOptionPane.showMessageDialog(null, "Livros exportados para " + filePath);
    }

    /* ===================== Autenticação e Autorização ====================== */
    public void Login(String userOrEmail, String password) {
        Usuario founded = null;
        if (!userOrEmail.isEmpty() || !password.isEmpty()) {
            if (!usuarios.isEmpty()) {
                for (var user : usuarios) {
                    if (user.getUserOrEmail().equals(userOrEmail)) {
                        founded = user;
                    }
                }
            }
        }

        if (founded != null) {
            String decryptedPassword = Usuario.decryptPassword(founded.getPassword());
            if (decryptedPassword.equals(password)) {
                usuarioLogado = founded;
                Notificar("Login", usuarioLogado.getUserOrEmail()+" Seja Bem-Vindo!!!!", JOptionPane.INFORMATION_MESSAGE);
                livroController.IndexAction();
            } else {
                Notificar("Alerta Login", "Senha errada, tenta novamente!!!!!!!", JOptionPane.WARNING_MESSAGE);
                loginController.LoginAction();
            }
        } else {
            Notificar("Alerta Login", "Usuário não encontrado!!!!!!!", JOptionPane.WARNING_MESSAGE);
            loginController.LoginAction();
        }
    }
    
    public void GoToSignUp(){
        loginController.SignUpAction();
    }
    
    public void SignUp(String userOrEmail, String password){
        try{
            Usuario novoUsuario = new Usuario();
            novoUsuario.setUserOrEmail(userOrEmail);
            novoUsuario.setPassword(password, false);
            usuarioDAO.adicionarUsuario(novoUsuario);
            Notificar("Criação de Conta", "Usuario criado com sucesso", JOptionPane.INFORMATION_MESSAGE);
            loginController.LoginAction();
        }catch(Exception ex){
            Notificar("Criação de Conta", "Erro ao criar conta!!!!!!", JOptionPane.WARNING_MESSAGE);
        }
        
    }

    public Boolean isAuthenticated() {
        return usuarioLogado != null;
    }

    public void LogOut() {
        usuarioLogado = null;
        loginController.LoginAction();
    }

    public void loadUsers() {
        usuarios = (ArrayList<Usuario>) usuarioDAO.listarUsuarios();
    }

    public void Notificar(String title, String message, int type) {
        Toolkit.getDefaultToolkit().beep();
        JOptionPane.showMessageDialog(null, message, title, type);
    }
}
