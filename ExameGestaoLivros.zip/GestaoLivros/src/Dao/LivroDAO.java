package Dao;

import Models.Livro;
import Models.Usuario;
import config.ConexaoBD;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

public class LivroDAO {
    private Connection connection;
    private UsuarioDAO usuarioDAO;

    public LivroDAO() {
        this.connection = ConexaoBD.getConnection();
        usuarioDAO = new UsuarioDAO();
    }

    public void adicionarLivro(Livro livro) {
        String sql = "INSERT INTO livros (title, description, author, createdAt, updatedAt, createdBy, updatedBy) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, livro.getTitle());
            stmt.setString(2, livro.getDescription());
            stmt.setString(3, livro.getAuthor());
            stmt.setDate(4, Date.valueOf(livro.getCreatedAt()));
            stmt.setDate(5, Date.valueOf(livro.getUpdatedAt()));
            stmt.setInt(6, livro.getCreatedBy().getId());
            stmt.setInt(7, livro.getUpdatedBy().getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void editarLivro(Livro livro) {
        String sql = "UPDATE livros SET title = ?, description = ?, author = ?, createdAt = ?, updatedAt = ?, createdBy = ?, updatedBy = ? WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, livro.getTitle());
            stmt.setString(2, livro.getDescription());
            stmt.setString(3, livro.getAuthor());
            stmt.setDate(4, Date.valueOf(livro.getCreatedAt()));
            stmt.setDate(5, Date.valueOf(livro.getUpdatedAt()));
            stmt.setInt(6, livro.getCreatedBy().getId());
            stmt.setInt(7, livro.getUpdatedBy().getId());
            stmt.setInt(8, livro.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void excluirLivro(int id) {
        String sql = "DELETE FROM livros WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Livro> listarlivros() {
        List<Livro> livros = new ArrayList<>();
        String sql = "SELECT * FROM livros";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Livro livro = new Livro();
                livro.setId(rs.getInt("id"));
                livro.setTitle(rs.getString("title"));
                livro.setDescription(rs.getString("description"));
                livro.setAuthor(rs.getString("author"));
                livro.setCreatedAt(rs.getDate("createdAt").toLocalDate());
                livro.setUpdatedAt(rs.getDate("updatedAt").toLocalDate());
                livro.setCreatedBy(usuarioDAO.buscarUsuarioPorId(rs.getInt("createdBy")));
                livro.setUpdatedBy(usuarioDAO.buscarUsuarioPorId(rs.getInt("updatedBy")));
                livros.add(livro);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return livros;
    }

    public void exportarLivrosParaPDF(String filePath) {
        String sql = "SELECT * FROM livros";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            Document document = new Document();
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();
            document.add(new Paragraph("Lista de Livros"));
            document.add(new Paragraph(" "));
            PdfPTable table = new PdfPTable(8);
            table.addCell("ID");
            table.addCell("Titulo");
            table.addCell("Descrição");
            table.addCell("Autor");
            table.addCell("Criado em");
            table.addCell("Atualizado em");
            table.addCell("Criado por");
            table.addCell("Atualizado por");
            while (rs.next()) {
                table.addCell(String.valueOf(rs.getInt("id")));
                table.addCell(rs.getString("title"));
                table.addCell(rs.getString("description"));
                table.addCell(rs.getString("author"));
                table.addCell(rs.getDate("createdAt").toString());
                table.addCell(rs.getDate("updatedAt").toString());
                table.addCell(usuarioDAO.buscarUsuarioPorId(rs.getInt("createdBy")).getUserOrEmail());
                table.addCell(usuarioDAO.buscarUsuarioPorId(rs.getInt("updatedBy")).getUserOrEmail());
            }
            document.add(table);
            document.close();
        } catch (SQLException | DocumentException | FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
