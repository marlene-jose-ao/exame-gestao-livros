
package Dtos;



public class LivroDTO {
    private String Title;
    private String Description;
    private String Author;

    public LivroDTO(String Title, String Description, String Author) {
        this.Title = Title;
        this.Description = Description;
        this.Author = Author;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String Title) {
        this.Title = Title;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public String getAuthor() {
        return Author;
    }

    public void setAuthor(String Author) {
        this.Author = Author;
    }

    
}
