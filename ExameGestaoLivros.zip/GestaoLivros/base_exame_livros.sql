/*
 Navicat Premium Data Transfer

 Source Server         : LocalMariaDBServer
 Source Server Type    : MariaDB
 Source Server Version : 100508 (10.5.8-MariaDB)
 Source Host           : localhost:3306
 Source Schema         : base_exame_livros

 Target Server Type    : MariaDB
 Target Server Version : 100508 (10.5.8-MariaDB)
 File Encoding         : 65001

 Date: 04/02/2025 15:40:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for livros
-- ----------------------------
DROP TABLE IF EXISTS `livros`;
CREATE TABLE `livros`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `author` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `createdAt` date NULL DEFAULT NULL,
  `updatedAt` date NULL DEFAULT NULL,
  `createdBy` int(11) NULL DEFAULT NULL,
  `updatedBy` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `createdBy`(`createdBy`) USING BTREE,
  INDEX `updatedBy`(`updatedBy`) USING BTREE,
  CONSTRAINT `livros_ibfk_1` FOREIGN KEY (`createdBy`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `livros_ibfk_2` FOREIGN KEY (`updatedBy`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of livros
-- ----------------------------
INSERT INTO `livros` VALUES (10, 'A caminhada para o sonho', 'Livro escrito no camama', 'Sebastão Monizz', '2025-02-04', '2025-02-04', 8, 8);

-- ----------------------------
-- Table structure for usuarios
-- ----------------------------
DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userOrEmail` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of usuarios
-- ----------------------------
INSERT INTO `usuarios` VALUES (8, 'admin', 'F/PZtTgA4k5q/9o6Jzik6w==');

SET FOREIGN_KEY_CHECKS = 1;
